import { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import Nav from '../components/Nav';

function Orders() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [completedOrders, setCompletedOrders] = useState([]);

  useEffect(() => {
    fetchOrderItems();
    fetchCompletedOrders();
  }, []);

  const fetchOrderItems = async () => {
    try {
      const response = await axios.get('http://localhost:8080/orderitem/getAllOrderItem');
      setOrders(response.data);
    } catch (error) {
      console.error('Error fetching order items:', error);
    }
  };

  const fetchCompletedOrders = async () => {
    try {
      const response = await axios.get('http://localhost:8080/delivery/getAllDelivery');
      setCompletedOrders(response.data);
    } catch (error) {
      console.error('Error fetching completed orders:', error);
    }
  };

  const handleFinishOrder = (orderId) => {
    const updatedOrders = orders.map(order =>
      order.id === orderId ? { ...order, status: 'Completed' } : order
    );
    setOrders(updatedOrders);
    const finishedOrder = orders.find(order => order.id === orderId);
    localStorage.setItem('completedOrders', JSON.stringify([...JSON.parse(localStorage.getItem('completedOrders') || '[]'), finishedOrder]));
  };

  return (
    <div>
      <Nav />
      <div className="flex">
        <div className="bg-orange-200 h-screen w-60 flex flex-col items-center justify-center">
          <button onClick={() => navigate("/orders")} className="px-12 py-7 text-2xl bg-orange-200 rounded-xl shadow-sm mb-4">Orders</button>
          <button onClick={() => navigate("/menu")} className="px-12 py-7 text-2xl bg-orange-200 rounded-xl shadow-sm mb-4">Menu</button>
          <button onClick={() => navigate("/order_history")} className="px-14 pt-4 pb-2.5 text-2xl bg-orange-200 rounded-xl shadow-sm mb-4">Order History</button>
        </div>

        <div className="flex-grow py-11 bg-amber-100 shadow-sm">
          <div className="text-2xl font-bold text-center text-black mb-5">Orders</div>
          <div className="flex gap-3 mb-5 justify-center">
            <button onClick={() => navigate("/order_details")} className="px-4 py-3 rounded-lg border-2 border-orange-600 bg-orange-600 text-white">New Orders</button>
            <button onClick={() => navigate("/completed_order")} className="px-4 py-3 rounded-lg border-2 border-orange-600 bg-orange-600 text-white">Completed Orders</button>
          </div>
          <div className="max-w-[984px] mx-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-orange-200 text-orange-600">
                  <th className="px-6 py-3 border border-orange-700">Name</th>
                  <th className="px-6 py-3 border border-orange-700">Contact</th>
                  <th className="px-6 py-3 border border-orange-700">Total Items</th>
                  <th className="px-6 py-3 border border-orange-700">Total Price</th>
                  <th className="px-6 py-3 border border-orange-700">Order Date</th>
                  <th className="px-6 py-3 border border-orange-700">Status</th>
                </tr>
              </thead>
              <tbody>
                {orders.filter(order => order.status === 'Pending').map((order) => (
                  <tr key={order.id}>
                    <td className="px-6 py-4 border border-gray-200">{order.name}</td>
                    <td className="px-6 py-4 border border-gray-200">{order.contact}</td>
                    <td className="px-6 py-4 border border-gray-200">{order.totalItems}</td>
                    <td className="px-6 py-4 border border-gray-200">{order.totalPrice}</td>
                    <td className="px-6 py-4 border border-gray-200">{order.orderDate}</td>
                    <td className="px-6 py-4 border border-gray-200">
                      <button onClick={() => handleFinishOrder(order.id)} className="px-4 py-2 bg-green-500 text-white rounded">Finish</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Orders;
